package iss.java.mail;

import javax.mail.*;
import java.io.IOException;
import java.util.Properties;

public class MailReceiver2014302580190 {
    /**
     * 接收邮件的props文件
     */
    private final Properties props = System.getProperties();
    /**
     * 邮件服务器登录验证
     */
    private MailAuthenticator2014302580190 authenticator;

    /**
     * 邮箱session
     */
    private Session session;

    /**
     * 初始化邮件发送器
     *
     * @param imapHostName
     *                IMAP邮件服务器地址
     * @param username
     *                发送邮件的用户名(地址)
     * @param password
     *                发送邮件的密码
     */
    public MailReceiver2014302580190(final String imapHostName, final String username,
                                     final String password) {
        // 初始化props
        props.put("mail.store.protocol", "imap");
        props.put("mail.imap.host", imapHostName);
        // 验证
        authenticator = new MailAuthenticator2014302580190(username, password);
        // 创建session
        session = Session.getInstance(props, authenticator);
    }

    /**
     * 检测是否有新邮件
     * @return 布尔值, 返回是否有新邮件到达
     * @throws MessagingException
     */
    public boolean listen() throws MessagingException {
        boolean flag = false;

        try {
            Store store = session.getStore();
            store.connect();
            Folder folder = store.getFolder("INBOX");
            folder.open(Folder.READ_ONLY);

            int newMessageCount = folder.getNewMessageCount();
            if (newMessageCount > 0) {
                flag = true;
            }

        } catch (NoSuchProviderException e) {
            e.printStackTrace();
        }
        return flag;
    }

    /**
     * 获取自动回复方法
     * @param sender 自动回复邮件的发件人邮箱地址
     * @param subject 自动回复邮件的主题
     * @return 自动回复邮件内容
     * @throws MessagingException
     * @throws IOException
     */
    public String getReplyMessageContent(String sender, String subject) throws MessagingException, IOException {

        String content = "未收到自动回复!";
        try {
            Store store = session.getStore();
            store.connect();
            Folder folder = store.getFolder("INBOX");
            folder.open(Folder.READ_ONLY);

            Message[] messages = folder.getMessages();


            for (Message message: messages) {
                //判断是否为
                String messageSubject = message.getSubject();
                if (messageSubject.contains("自动回复")) {
                    content = (String)message.getContent();
                }
            }

        } catch (NoSuchProviderException e) {
            e.printStackTrace();
        }

        return content;
    }
}
