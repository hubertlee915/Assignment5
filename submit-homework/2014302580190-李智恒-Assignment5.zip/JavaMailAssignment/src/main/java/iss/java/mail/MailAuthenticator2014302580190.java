package iss.java.mail;

import javax.mail.Authenticator;
import javax.mail.PasswordAuthentication;

public class MailAuthenticator2014302580190 extends Authenticator {
    /**
     * 用户名
     */
    private String username;
    /**
     * 密码
     */
    private String password;

    /**
     * 初始化邮箱和密码
     *
     * @param username 邮箱
     * @param password 密码
     */
    public MailAuthenticator2014302580190(String username, String password) {
        this.username = username;
        this.password = password;
    }


    /**
     * 用户名获取方法
     * @return username
     */
    String getUsername() {
        return username;
    }

    /**
     * 密码的获取方法
     * @return password
     */
    String getPassword() {
        return password;
    }

    /**
     * 用户名的设置方法
     * @param username 用户名
     */
    public void setUsername(String username) {
        this.username = username;
    }

    /**
     * 密码的设置方法
     * @param password 密码
     */
    public void setPassword(String password) {
        this.password = password;
    }


    /**
     * passwordAuthentication的获取方法
     * @return passwordAuthentication
     */
    @Override
    protected PasswordAuthentication getPasswordAuthentication() {
        return new PasswordAuthentication(username, password);
    }

}
