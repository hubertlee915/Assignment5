package iss.java.mail;

import javax.mail.MessagingException;
import java.io.IOException;

/**
 * Created by Hubert on 15/11/23.
 */
public class MailService2014302580190 implements IMailService {

    /**
     * 邮件发送器, 用于发送邮件
     */
    private MailSender2014302580190 sender;
    /**
     * 邮件接收器,用于接收邮件
     */
    private MailReceiver2014302580190 receiver;

    /**
     * 用户名, 用于测试
     */
    private static final String USERNAME = "hubertlee915@163.com";
    /**
     * 密码, 用于测试
     */
    private static final String PWD = "bkedmbvejxtklhdj";

    /**
     * 连接邮箱服务器, 并初始化sender和receiver
     * @throws MessagingException
     */
    public void connect() throws MessagingException {
        sender = new MailSender2014302580190("smtp.163.com", USERNAME, PWD);
        receiver = new MailReceiver2014302580190("imap.163.com", USERNAME, PWD);
    }

    /**
     * 发送邮件方法
     * @param recipient 收件人邮箱地址
     * @param subject 邮件主题
     * @param content 邮件正文
     * @throws MessagingException
     */
    public void send(String recipient, String subject, Object content) throws MessagingException {
        sender.send(recipient, subject, content);
    }

    /**
     * 询问服务器是否有新邮件到达
     * @return 布尔值, 返回是否有新邮件到达
     * @throws MessagingException
     */
    public boolean listen() throws MessagingException {
        return receiver.listen();
    }

    /**
     *
     * @param sender 自动回复的发件人邮箱地址
     * @param subject 自动回复的主题
     * @return 自动回复邮件的内容
     * @throws MessagingException
     * @throws IOException
     */
    public String getReplyMessageContent(String sender, String subject) throws MessagingException, IOException {
        return receiver.getReplyMessageContent(sender, subject);
    }
}
